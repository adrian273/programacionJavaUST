
package sistemaregistrogaudi;

import sistemaregistrogaudi.gui.App;

/**
 *
 * @author adrian
 */
public class SistemaRegistroGAUDI {

    
    public static void main(String[] args) {
       new App().setVisible(true);
    }
    
}
