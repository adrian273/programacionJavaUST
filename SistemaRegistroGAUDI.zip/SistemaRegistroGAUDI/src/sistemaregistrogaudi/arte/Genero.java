
package sistemaregistrogaudi.arte;

/**
 *
 * @author adrian
 */
public enum Genero {
    RETRATO,
    DESNUDO,
    NATURALEZA_MUERTA,
    PINTURA_PAISAJISTE,
    PINTURA_HISTORICA
}
