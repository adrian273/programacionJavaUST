
package sistemaregistrogaudi.arte;

/**
 *
 * @author adrian
 */
public enum Tecnica {
    ACUARELA, 
    OLEO, 
    FRESCO, 
    TEMPLE, 
    PUNTILLISMO
}
