package tallermecanica;

/**
 *
 * @author adrian
 * @since 22/06/2018
 * 
 */

public class TallerMecanica {
    
    public static void main(String[] args) {
        new AplicationGUI().setVisible(true);
    }
    
}
